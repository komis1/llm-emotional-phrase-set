<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1 maximum-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>LLM Corpus Experiment</title>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/platform/1.3.6/platform.min.js"></script>

    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
    <![endif]-->

<script>

function isMobile() {
  const minWidth = 768; // Minimum width for desktop devices
  const regex = /Mobi|Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
  console.log(regex.test(navigator.userAgent));
  console.log(window.innerWidth < minWidth || screen.width < minWidth);
  console.log('ontouchstart' in window && navigator.maxTouchPoints > 1);
  return regex.test(navigator.userAgent) && (window.innerWidth < minWidth || screen.width < minWidth) && ('ontouchstart' in window && navigator.maxTouchPoints > 1);
}

function init(){

  if(!isMobile()){
    //window.location='error.php';
  }

  let url = new URL(window.location);
  let params = new URLSearchParams(url.search);
  extype = params.get('type');
  console.log("ex type = "+extype);
  if (extype<=10){
    document.getElementById("prompts").style="display:none";
    document.getElementById("noprompts").style="display:block";
  }
  else{

      document.getElementById("prompts").style="display:block";
      document.getElementById("noprompts").style="display:none";

  }
  showbutton();
}

function go(){
  let url = new URL(window.location);
  let params = new URLSearchParams(url.search);
  extype = params.get('type');
  window.location = "video.php?type="+extype;
}

function showbutton(){
  //console.log(document.getElementById("ready").value);
  if (document.getElementById("ready").value==1){
    document.getElementById("go").disabled=false;
  }
  else{
    document.getElementById("go").disabled=true;
  }
}

</script>

<style>

.vertical-center {
  margin: 0;
  position: absolute;
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
.row{
  margin-bottom: 1em;
}
.promptbubble{
  background-color: #3366ff;
  color: white;
  border-radius: 12px;
  margin: 0.5em;
  padding: 1em;
}

.responsebubble{
  background-color: #9966ff;
  color: white;
  border-radius: 12px;
  margin: 0.5em;
  padding: 1em;
  font-style: italic;
}
h1, h3{
  text-align: center;
}

.responsebubble-small{
  background-color: #9966ff;
  color: white;
  border-radius: 6px;
  padding: 0.1em;
  font-style: italic;
}

.promptbubble-small{
  background-color: #3366ff;
  color: white;
  border-radius: 6px;
  padding: 0.1em;
  font-style: italic;
}
input{
  border-radius: 12px;
  width: 100%;
  text-align: center;
}
button:enabled {
  background: #3cb371;
  color: white;
  text-shadow: none;
}

button:disabled {
  background: #dddddd;
}

select{
  border-radius: 12px;
  width: 100%;
  text-align: center;
}

body{
  margin:1em;
}

/*#prompt{
  animation: pop 0.3s linear 2;
}*/

@keyframes pop{
  50%  {transform: scale(1.2);}
}

</style>
<!-- Include all compiled plugins (below), or include individual files as needed -->
</head>
<body onload="init()">
  <h1>LLM Corpus Text Entry Experiment</h1>
  <hr/>
  <h3><i class="bi bi-info-square-fill"></i> Task Instructions <i class="bi bi-info-square-fill"></i></h3>
  <hr>
  <div class="container">
  <div class="row" id="prompts" hidden>
    <div class = "col-xs-12"> <p>Imagine you are engaged in a person-to-person or group chat using your mobile. You will see a message being sent to you in the <span class="promptbubble-small">blue bubble</span>. The reply that you wish to send, will appear after a few seconds, in the <span class="responsebubble-small">purple bubble</span>).
      <p>Your task is to type the text of the message in the purple bubble, as <strong>quickly</strong> and as <strong>accurately</strong> as you can, but <strong>be careful!</strong>
      <p>You need to <strong>memorize</strong> your reply, because the text in the purple bubble will disappear once you start typing!</p>
      <p>While typing, you may use word completions or suggestions as you would regularly.</p>
      </div>
    <div class = "col-xs-12"> <hr></div>
    <div class="col-xs-6 text-center"><img src="img/prompt_1.png" class="img-fluid" style="width:100%;"/></div>
    <div class="col-xs-6 text-center"><img src="img/prompt_2.png" class="img-fluid" style="width:100%;"/></div>
    <div class="col-xs-6 text-center"><em>Your task is to type the message in the purple bubble.<em></div>
    <div class="col-xs-6 text-center"><em>When you start typing, the text disappears and you need to remember it.<em></div>
    </div>
  </div>
  <div class="row" id="noprompts" hidden>
    <div class = "col-xs-12"> <p>Imagine you are trying to send a person-to-person or group chat message, using your mobile.
      The message that you intend to send will appear inside a <span class="responsebubble-small">coloured bubble</span>.
      <p>Your task is to type the text of the message, as <strong>quickly</strong> and as <strong>accurately</strong> as you can.
      <p>While typing, you may use word completions or suggestions as you would regularly.
    </div>

    <div class = "col-xs-12"> <hr></div>
    <div class="col-xs-12 text-center"><img src="img/no_prompt_1.png" class="img-fluid" style="width:100%;"/></div>
    <div class="col-xs-3"></div>
    <div class="col-xs-6 text-center"><em>Your task is to type the message in the<br><span class="responsebubble-small">coloured</span></br> bubble.<em></div>
    <div class="col-xs-3"></div>
  </div>
  <div class="row">
    <div class = "col-xs-12"> <hr></div>
    <div class="col-xs-8"><em><strong>I confirm that I have read these instructions carefully, and I am ready to start.</strong></em></div>
    <div class="col-xs-4 align-self-center">
      <select class="form-select" id="ready" onchange="showbutton()">
        <option value="un" selected>- Select -</option>
        <option value="1">I confirm this.</option>
    </select>
    </div>
  </div>
  <div class="row">
    <div class = "col-xs-12"> <hr></div>
    <div class="col-xs-12" style="text-align:center;"><button class="btn btn-default" id = "go" onclick="go()" disabled>Proceed</button>
  </div>
</div>
</body>
</html>
