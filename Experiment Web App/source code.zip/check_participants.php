<?php
header("Content-Type: application/json; charset=UTF-8");

include "connection.php";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn, "utf8mb4");


$status=[];


// Check connection
if ($conn->connect_error) {
  $status["code"]=0;
  $status["message"]=$conn->connect_error;
}


$sql1 = "select * from participants";

if ($result=$conn->query($sql1)) {
  $status["code"]=1;
  $status["participants"]=$result->num_rows;
  //$status["sql"]=$sql1."; ".$sql2;
}
else {
  $status["code"]=0;
  $status["message"]=$conn->error;
}


echo json_encode($status);
?>
