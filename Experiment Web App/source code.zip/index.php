<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>LLM Corpus Experiment</title>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/platform/1.3.6/platform.min.js"></script>

    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
    <![endif]-->

<script>

  function init(){

    if(!isMobile()){
      //window.location='error.php';
    }
    //generate participantID if not from prolific

    if (!localStorage.pid){
      let url = new URL(window.location);
      let params = new URLSearchParams(url.search);
      pid = params.get('PROLIFIC_PID');

      if (pid){
        localStorage.pid = pid;
        localStorage.ptype = "prolific";
        localStorage.cc = "CFB1R1IN";
      }
      else{
        localStorage.pid = "id" + Math.random().toString(16).slice(2);
        localStorage.ptype = "local";
      }
      document.getElementById("pid").innerHTML=localStorage.pid;
    }
    else {
      document.getElementById("pid").innerHTML=localStorage.pid;
    }

    if (localStorage.experimentorder){
      document.getElementById("experiments").innerHTML=JSON.parse(localStorage.experimentorder).exorder.length;
      if (document.getElementById("experiments").innerHTML == "0"){
        document.getElementById("begin").innerHTML="All Done!";
        document.getElementById("save").disabled=true;
        document.getElementById("begin").disabled=true;

        cdiv = document.getElementById("completed");
        cdiv.innerHTML="<hr>"+
        "<h3 style=\"text-align:center;\"><i class='bi bi-info-circle-fill'></i>&nbsp;The experiment is complete!</h3>";
        if (localStorage.ptype == 'prolific'){
          cdiv.innerHTML+="Please go to Prolific and enter the following completion code to complete the study, or click on the code to automatically redirect back to Prolific!"+
          "<h3 style=\"text-align:center;\"><a href=\"https://app.prolific.com/submissions/complete?cc="+localStorage.cc+"\">"+localStorage.cc+"</a></h3>";
        }
        document.getElementById("demographics").style="display:none;";
      }
    }

    if (localStorage.gender){
      if (localStorage.gender!="un"){
        document.getElementById("gender").value=localStorage.gender;
        document.getElementById("gender").disabled=true;
      }
    }
    if (localStorage.age){
      if (localStorage.age!=""){
        document.getElementById("age").value=localStorage.age;
        document.getElementById("age").disabled=true;
      }
    }
    if (localStorage.english){
      if (localStorage.english!="un"){
        document.getElementById("english").value=localStorage.english;
        document.getElementById("english").disabled=true;
      }
    }
    if (localStorage.fingers){
      if (localStorage.fingers!="un"){
        document.getElementById("fingers").value=localStorage.fingers;
        document.getElementById("fingers").disabled=true;
      }
    }
    if (localStorage.autocorrect){
      if (localStorage.autocorrect!="un"){
        document.getElementById("autocorrect").value=localStorage.autocorrect;
        document.getElementById("autocorrect").disabled=true;
      }
    }
    if (localStorage.wordsuggestions){
      if (localStorage.wordsuggestions!="un"){
        document.getElementById("wordsuggestions").value=localStorage.wordsuggestions;
        document.getElementById("wordsuggestions").disabled=true;
      }
    }


    if (!localStorage.timeZone){
      localStorage.timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    }

    if (!localStorage.locale){
      localStorage.locale = Intl.DateTimeFormat().resolvedOptions().locale;
    }

    if (localStorage.education){
      if (localStorage.education!="un"){
        document.getElementById("education").value=localStorage.education;
        document.getElementById("education").disabled=true;
      }
    }

    if (localStorage.occupation){
      if (localStorage.occupation!="un"){
        document.getElementById("occupation").value=localStorage.occupation;
        document.getElementById("occupation").disabled=true;
      }
    }



    if(localStorage.wpms && localStorage.edists){
      table = document.getElementById("performance");
      wpms = localStorage.wpms.split(";");
      edists = localStorage.edists.split(";");
      for (i=0;i<wpms.length;i++){
        var row = table.insertRow(-1);
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);
        cell1.innerHTML = "Exp. "+(i+1).toString();
        cell2.innerHTML = wpms[i];
        cell3.innerHTML = edists[i];

      }
    }

    if(localStorage.length>=13){
      document.getElementById("save").disabled=true;
      // if no experiments remaining, disable the begin experiment button
      if (document.getElementById("experiments").innerHTML != "0"){
        document.getElementById("begin").disabled=false;
      }
    }
  }

  function check_participants(){

        //select experiment order based on latin square
        /*
        Experiments:

        1 - val+ ar+
        2 - val+ ar-
        3 - val- ar+
        4 - val- ar-
        5 - va0 ar0

        */
    if (!localStorage.experimentorder){ //cache has been cleared
      var xhr = new XMLHttpRequest();
      //open the request
      xhr.open('GET','check_participants.php');
      xhr.setRequestHeader("Content-type", "application/*.*");
      xhr.send();
      xhr.onreadystatechange = function() {
          if (xhr.readyState == XMLHttpRequest.DONE) {
              //document.getElementById("results").innerHTML = JSON.parse(this.responseText)['message'];
              nparticipants = JSON.parse(this.responseText)['participants']

              console.log(JSON.parse(this.responseText));
              console.log(nparticipants);

              const conditions=[
                [1,2,4,3],
                [2,3,1,4],
                [3,4,2,1],
                [4,1,3,2]
              ];

              chosen_condition = nparticipants%4;


              conditions[chosen_condition].splice(2,0,5);
              conditions[chosen_condition].unshift(5);

              console.log(conditions[chosen_condition]);
              localStorage.experimentorder = JSON.stringify({"exorder":conditions[chosen_condition]});
              init();
          }
      }
    }
    else{
      init();
    }

  }

  function isMobile() {
    const minWidth = 768; // Minimum width for desktop devices
    const regex = /Mobi|Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
    console.log(regex.test(navigator.userAgent));
    console.log(window.innerWidth < minWidth || screen.width < minWidth);
    console.log('ontouchstart' in window && navigator.maxTouchPoints > 1);
    return regex.test(navigator.userAgent) && (window.innerWidth < minWidth || screen.width < minWidth) && ('ontouchstart' in window && navigator.maxTouchPoints > 1);
  }


  function shuffle(array) {
    let currentIndex = array.length;

    // While there remain elements to shuffle...
    while (currentIndex != 0) {

      // Pick a remaining element...
      let randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;

      // And swap it with the current element.
      [array[currentIndex], array[randomIndex]] = [
        array[randomIndex], array[currentIndex]];
    }
  }


  function start(){
    nextexp = JSON.parse(localStorage.experimentorder).exorder[0];
    window.location = "consent.php?type="+nextexp;
  }

  function sendtoserver(){

    localStorage.age = document.getElementById("age").value;

    var qs = document.getElementsByTagName("select");
    for (i=0;i<qs.length; i++){
      if (qs[i].value!="un"){ //save values for all provided answers
        localStorage[qs[i].id]=qs[i].value;
      }
    }

    data={"pid":localStorage.pid,
          "age":localStorage.age,
          "english":localStorage.english,
          "gender":localStorage.gender,
          "fingers":localStorage.fingers,
          "autocorrect":localStorage.autocorrect,
          "wordsuggestions":localStorage.wordsuggestions,
          "timezone":localStorage.timeZone,
          "locale":localStorage.locale,
          "ptype":localStorage.ptype,
          "education":localStorage.education,
          "occupation":localStorage.occupation
        };

    console.log("sending "+ JSON.stringify(data));
    var xhr = new XMLHttpRequest();
    //open the request
    xhr.open('POST','sendtoserver.php');
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("p=" + JSON.stringify(data));

    xhr.onreadystatechange = function() {
        if (xhr.readyState == XMLHttpRequest.DONE) {
            //document.getElementById("results").innerHTML = JSON.parse(this.responseText)['message'];
            console.log(JSON.parse(this.responseText));
            location.reload();
        }
    }
    //Dont submit the form.
    return false;
  }

</script>

<style>
.row{
  margin-bottom: 1em;
}
.promptbubble{
  background-color: #3366ff;
  color: white;
  border-radius: 12px;
  margin: 0.5em;
  padding: 1em;
}

.responsebubble{
  background-color: #9966ff;
  color: white;
  border-radius: 12px;
  margin: 0.5em;
  padding: 1em;
  font-style: italic;
}
h1{
  text-align: center;
}
button:enabled {
  background: #3cb371;
  color: white;
  text-shadow: none;
}

button:disabled {
  background: #dddddd;
}
input{
  border-radius: 12px;
  width: 100%;
  text-align: center;
}

select{
  border-radius: 12px;
  width: 100%;
  text-align: center;
}

body{
  margin:1em;
}

/*#prompt{
  animation: pop 0.3s linear 2;
}*/

@keyframes pop{
  50%  {transform: scale(1.2);}
}

</style>
<!-- Include all compiled plugins (below), or include individual files as needed -->
  </head>
  <body onload="check_participants()">
    <h1>LLM Corpus Text Entry Experiment</h1>
    <div class="row">
      <div class="col-xs-5">Your participant ID is:</div>
      <div class="col-xs-7">
        <span id="pid"/>
      </div>
    </div>
    <div class="row">
      <div class="col-xs-5">Phrase sets remaining to complete:</div>
      <div class="col-xs-7">
        <span id="experiments"/>
      </div>
    </div>
    <div class="row"><div class="col-xs-12" id="completed"></div></div>
    <hr/>
    <form action="javascript:void(0);" onsubmit="sendtoserver()">
      <div class="container" id="demographics">
        <div class="row">
          <h3>Your demographics</h3>
          <div class="col-xs-5">Please select your gender</div>
          <div class="col-xs-7">
            <select class="form-select" id="gender" required>
              <option value="" selected>- Select One -</option>
              <option value="f">Female</option>
              <option value="m">Male</option>
              <option value="o">Other non-binary</option>
              <option value="u">Prefer not to disclose</option>
          </select>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-5">Please enter your age</div>
          <div class="col-xs-7">
            <input type="number" id="age" min="18", max="90" required/>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-5">What is your main occupation?</div>
          <div class="col-xs-7">
            <select class="form-select" id="occupation" required>
              <option value="" selected>- Select One -</option>
              <option value="1">Student</option>
              <option value="2">Self-employed</option>
              <option value="3">Employed</option>
              <option value="4">Home-maker</option>
              <option value="5">Retired</option>
              <option value="6">Unemployed</option>
          </select>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-5">What is your current highest educational achievement?</div>
          <div class="col-xs-7">
            <select class="form-select" id="education" required>
              <option value="" selected>- Select One -</option>
              <option value="1">High-school diploma</option>
              <option value="2">Vocational training diploma</option>
              <option value="3">University degree</option>
              <option value="4">Postgraduate degree (Masters)</option>
              <option value="5">Doctorate</option>
          </select>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-5">Please select your English language certification level</div>
          <div class="col-xs-7">
            <select class="form-select" id="english" required>
              <option value="" selected>- Select One -</option>
              <option value="NA">Native Speaker</option>
              <option value="C2">C2 - Proficient</option>
              <option value="C1">C1 - Advanced</option>
              <option value="B2">B2 - Upper Intermediate</option>
              <option value="B1">B1 - Intermediate</option>
              <option value="A2">A2 - Elementary</option>
              <option value="A1">A1 - Beginner</option>
              <option value="NN">Non-native speaker without certification</option>
          </select>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-5">You usually type on your mobile with...</div>
          <div class="col-xs-7">
            <select class="form-select" id="fingers" required>
              <option value="" selected>- Select One -</option>
              <option value="i">Single finger (index)</option>
              <option value="t">Single finger (thumb)</option>
              <option value="tt">Two thumbs</option>
              <option value="gl">Glide / Swipe typing</option>
          </select>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-5">Do you have Autocorrect enabled on your mobile keyboard?</div>
          <div class="col-xs-7">
            <select class="form-select" id="autocorrect" required>
              <option value="" selected>- Select One -</option>
              <option value="1">Yes</option>
              <option value="2">No</option>
          </select>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-5">How often do you use Word Suggestions when you type messages on your mobile keyboard?</div>
          <div class="col-xs-7">
            <select class="form-select" id="wordsuggestions" required>
              <option value="" selected>- Select One -</option>
              <option value="1">Never</option>
              <option value="2">Rarely</option>
              <option value="3">Sometimes</option>
              <option value="4">Often</option>
              <option value="5">All the time</option>
          </select>
          </div>
        </div>
      <div class="row">
        <div class="col-xs-6"><button type="submit" class="btn btn-default" id ="save">Save my profile</button></div>
        <div class="col-xs-6"><button type="button" class="btn btn-default" id="begin" onclick = "start()" disabled>Begin next experiment</button></div>
      </div>
      <hr>
    </div>
  </form>
  <div class="container">
    <div class="row">
      <h3>Performance metrics</h3>
      <div class="col-xs-12">
      Your performance is measured in average <em>Words Per Minute</em> per phrase (typing speed - higher is better) and average <em>Errors</em> per phrase (number of character edits needed to match the target phrase, lower is better).
      </div>
    </div>
    <div class="row">
      <div class="col-xs-12">
        <table class="table" id = "performance">
          <thead class="thead-dark">
            <tr>
              <th scope="col">Experiment</th>
              <th scope="col">WPM</th>
              <th scope="col">Errors</th>
            </tr>
          </thead>
          <tbody id = "performance-b">
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
</html>
