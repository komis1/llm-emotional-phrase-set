<?php
$servername = "[YOUR SETTING HERE]"; //server address, e.g. localhost
$username = "[YOUR SETTING HERE]";
$password = "[YOUR SETTING HERE]";
$dbname = "[YOUR SETTING HERE]";
?>
