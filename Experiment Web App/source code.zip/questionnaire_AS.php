<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>LLM Corpus Experiment</title>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
    <![endif]-->

<script>
  const start_time=Date.now();
  var questions = new Array();

  function isMobile() {
    const minWidth = 768; // Minimum width for desktop devices
    const regex = /Mobi|Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
    console.log(regex.test(navigator.userAgent));
    console.log(window.innerWidth < minWidth || screen.width < minWidth);
    console.log('ontouchstart' in window && navigator.maxTouchPoints > 1);
    return regex.test(navigator.userAgent) && (window.innerWidth < minWidth || screen.width < minWidth) && ('ontouchstart' in window && navigator.maxTouchPoints > 1);
  }


  function shuffle(array) {
    let currentIndex = array.length;

    // While there remain elements to shuffle...
    while (currentIndex != 0) {

      // Pick a remaining element...
      let randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;

      // And swap it with the current element.
      [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
    }
  }

  async function getData(url, qs) {
    const response = await fetch(url);
    const data = await response.json();
    console.log(data);
    for (i=0;i<data.questions.length;i++){
      qs.push(data.questions[i]);
    }
    shuffle(qs);
    console.log(qs);
    populate_page(qs);
  }


  //<label for="customRange3" class="form-label">Example range</label>
  //<input type="range" class="form-range" min="0" max="5" step="0.5" id="customRange3">

  function populate_page(qs){
    for (i=0;i<qs.length; i++){

      qdiv= document.getElementById("questionsdiv");
      rdiv = document.createElement("div");
      rdiv.className = "row";
      qdiv.appendChild(rdiv);
      qtextdiv = document.createElement("div");
      qtextdiv.className="col-xs-12";
      qtextdiv.innerHTML= (i+1)+". "+qs[i].text;
      rdiv.appendChild(qtextdiv);
      qseldiv = document.createElement("div");
      qseldiv.className="col-xs-12";
      rdiv.appendChild(qseldiv);

      //sliderlabel = document.createElement("label");
      //sliderlabel.for = "q"+qs[i].id;
      //sliderlabel.className = "form-label";
      //sliderlabel.innerHTML = qs[i].responses.labels;

      slider = document.createElement("input");
      slider.type="range";
      slider.className="form-range";
      slider.required = true;
      slider.min=qs[i].responses.min;
      slider.max=qs[i].responses.max;
      slider.step=qs[i].responses.step;
      slider.value=slider.max/2;
      slider.id="q"+qs[i].id;
      qseldiv.appendChild(slider);
      //qseldiv.appendChild(sliderlabel);


      if (qs[i].responses.icons){
        ldiv = document.createElement("div");
        ldiv.className = "col-xs-1 left";
        cdiv = document.createElement("div");
        cdiv.className = "col-xs-10 center";
        rdiv = document.createElement("div");
        rdiv.className = "col-xs-1 right";
        lim = document.createElement("img");
        lim.src = "img/"+qs[i].responses.icons[0];
        rim = document.createElement("img");
        rim.src = "img/"+qs[i].responses.icons[1];
        cim = document.createElement("img");
        cim.src = "img/AS_intensity_cue.png";
        ldiv.appendChild(lim);
        rdiv.appendChild(rim);
        cdiv.appendChild(cim);
      }
      else
      {
        ldiv = document.createElement("div");
        ldiv.className = "col-xs-4 left";
        cdiv = document.createElement("div");
        cdiv.className = "col-xs-4 center";
        rdiv = document.createElement("div");
        rdiv.className = "col-xs-4 right";
        ldiv.innerHTML = "<strong>"+qs[i].responses.labels[0]+"</strong>";
        rdiv.innerHTML = "<strong>"+qs[i].responses.labels[1]+"</strong>";
      }

      qseldiv.appendChild(ldiv);
      qseldiv.appendChild(cdiv);
      qseldiv.appendChild(rdiv);

    }

    /*
      <div class="row">
        <div class="col-xs-6">20. My mind worked in total harmony with my body.</div>
        <div class="col-xs-6">
          <select class="form-select" id="q20">
            <option value="un" selected>- Select One -</option>
            <option value="1">Strongly disagree</option>
            <option value="2">Disagree</option>
            <option value="3">Neither agree nor disagree</option>
            <option value="4">Agree</option>
            <option value="5">Strongly Agree</option>
        </select>
        </div>
      </div>
    */

  }

  function init(){

    if(!isMobile()){
      //window.location='error.php';
    }

    getData("./questionnaire.json", questions);
    document.getElementById("pid").innerHTML+=localStorage.pid;
  }

  function sendtoserver(){
    console.log("sending...");
    /*for (i=1;i<=questions.length; i++){
      elid = "q"+i.toString();
      document.getElementById(elid).value = Math.floor(Math.random() * (5 - 1 + 1)) + 1;
    }*/

    /*for (i=1;i<=questions.length; i++){
      elid = "q"+i.toString();
      if (document.getElementById(elid).value=="un"){
        alert("Please provide an answer to every question");
        return;
      }
    }*/

    data={};
    for (i=1;i<=questions.length; i++){
      elid = "q"+i.toString();
      data[elid]=parseInt(document.getElementById(elid).value);
    }
    let url = new URL(window.location);
    let params = new URLSearchParams(url.search);
    data["extype"]=parseInt(params.get('type'));
    data["pid"]=localStorage.pid;
    data["start"]=start_time;

    console.log("sending "+ JSON.stringify(data));
    var xhr = new XMLHttpRequest();
    //open the request

    xhr.open('POST','sendtoserver.php');
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("q=" + JSON.stringify(data));

    xhr.onreadystatechange = function() {
        if (xhr.readyState == XMLHttpRequest.DONE) {
            //document.getElementById("results").innerHTML = JSON.parse(this.responseText)['message'];
            console.log(JSON.parse(this.responseText));
            window.location="index.php";
        }
    }

    //Dont submit the form.
    return false;
  }

</script>

<style>

.center{
  text-align: center;
  padding: 0px;
}

.left{
  text-align: left;
  padding: 0px;
}
.right{
  text-align: right;
  padding: 0px;
}
.accent {
  background-color: transparent;

}


.row{
  margin-bottom: 1.5em;
}
.promptbubble{
  background-color: #3366ff;
  color: white;
  border-radius: 12px;
  margin: 0.5em;
  padding: 1em;
}

.responsebubble{
  background-color: #9966ff;
  color: white;
  border-radius: 12px;
  margin: 0.5em;
  padding: 1em;
  font-style: italic;
}
h1{
  text-align: center;
}

input{
  border-radius: 12px;
  width: 100%;
  text-align: center;
}

select{
  border-radius: 12px;
  width: 100%;
  text-align: center;
}

body{
  margin:1em;
}

/*#prompt{
  animation: pop 0.3s linear 2;
}*/

@keyframes pop{
  50%  {transform: scale(1.2);}
}

img{
  width: 100%;
  height: 100%
}

</style>
<!-- Include all compiled plugins (below), or include individual files as needed -->
  </head>
  <body onload=init()>
    <h1>Experience questionnaire</h1>
    <div class="row">
      <div class="col-xs-5">Your participant ID is:</div>
      <div class="col-xs-7">
        <span id="pid"></span>
      </div>
    </div>
    <hr/>
    <form action="javascript:void(0);" onsubmit = "sendtoserver()">
      <div class="container" id="questionsdiv">
        <p>Please indicate your subjective experience in the experiment you just performed.</p>
      </div>
      <div class="row">
        <div class="col-xs-12" style="text-align: center"><span><button type="submit" class="btn btn-default" id ="save">Submit</button></span></div>
      </div>
    </form>

</body>
</html>
