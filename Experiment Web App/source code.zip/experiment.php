<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1 maximum-scale=1" >
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>LLM Corpus Experiment</title>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
    <![endif]-->

<script>



  var rec_keys = new Array();
  var typewriter = new Array();
  var phrases = new Array();
  var current_phrase = 0;
  var event_list = new Array();
  var extype = -1;
  var prompts = false;
  var sub_phrases = new Array();
  var firstevent;
  var lastevent;
  var n_questions = 15;
  var wpm=0;

  const names = ['Velma', 'Debra', 'Amy', 'Ethan', 'Kelly', 'Arlie', 'Mohammed', 'Jake', 'June', 'Barney', 'Amanda',
    'Dorothy', 'Arlen', 'Jerri', 'Octavio', 'Alvaro', 'Ladonna', 'Mildred', 'John', 'Rhea', 'Barrett', 'Carla',
    'Lauren', 'Estelle', 'Rita', 'Jarrett', 'Teresa', 'Traci', 'Pierre', 'Beth', 'Benito', 'Anna', 'Emerson',
    'Eugene', 'Adriana', 'Liza', 'Herbert', 'Leon', 'Laura', 'Curtis', 'Sharon', 'Allie', 'Kellie', 'Luther',
    'Burt', 'Scotty', 'Jordon', 'Lilly', 'Leanne', 'Jillian'];

  const surnames = ['Shah', 'Morton', 'Valencia', 'Scott', 'Costa', 'Weeks', 'Cohen', 'Arnold', 'Ellis', 'Camacho',
  'Dickson', 'Cummings', 'Fuller', 'Stephenson', 'Grimes', 'Dudley', 'Wall', 'Lopez', 'Meyers', 'Lozano', 'Espinoza',
  'Morrison', 'Shannon', 'Black', 'Gibbs', 'Chapman', 'Thornton', 'Little', 'Barr', 'Dennis', 'Cannon', 'Keith', 'Cain',
  'Cunningham', 'Combs', 'Vargas', 'Simpson', 'May', 'Krause', 'Wallace', 'Leon', 'Velez', 'Monroe', 'Romero', 'Nixon',
  'Moon', 'Payne', 'Ritter', 'Porter', 'Mcdowell']

  const levenshteinDistance = (s, t) => {
    if (!s.length) return t.length;
    if (!t.length) return s.length;
    const arr = [];
    for (let i = 0; i <= t.length; i++) {
      arr[i] = [i];
      for (let j = 1; j <= s.length; j++) {
        arr[i][j] =
          i === 0
            ? j
            : Math.min(
                arr[i - 1][j] + 1,
                arr[i][j - 1] + 1,
                arr[i - 1][j - 1] + (s[j - 1] === t[i - 1] ? 0 : 1)
              );
      }
    }
    return arr[t.length][s.length];
  };

  function isMobile() {
    const minWidth = 768; // Minimum width for desktop devices
    const regex = /Mobi|Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
    console.log(regex.test(navigator.userAgent));
    console.log(window.innerWidth < minWidth || screen.width < minWidth);
    console.log('ontouchstart' in window && navigator.maxTouchPoints > 1);
    return regex.test(navigator.userAgent) && (window.innerWidth < minWidth || screen.width < minWidth) && ('ontouchstart' in window && navigator.maxTouchPoints > 1);
  }


  function random_picks(jsondata, pics){

    var arr = [];
    while(arr.length < pics){
        var r = Math.floor(Math.random() * jsondata.length); //array position 0 to arr len -1
        if(arr.indexOf(r) === -1)
        {
          arr.push(r);
        }
    }
    return arr;
  }

  async function getData(url, nphrases) {
    const response = await fetch(url);
    const data = await response.json();
    const rands = await random_picks(data, nphrases);
    console.log(rands);
    for (i=0;i<rands.length;i++){
      phrases.push(data[rands[i]]);
    }
    populate_dialog(phrases[0]);
  }

  function populate_dialog(jsonobject){
      document.getElementById("namerow").innerHTML=names[random_picks(names,1)[0]]+" "+surnames[random_picks(surnames,1)[0]];
      document.getElementById('inputphrase').disabled=true;
      document.getElementById('inputphrase').value=null;
      document.getElementById("response").innerHTML="";

      if (prompts){
        document.getElementById("prompt").innerHTML=jsonobject['final_prompt'];
        document.getElementById("promptarea").style = "display:block";
        if(typewriter[current_phrase]==1){
          setTimeout(tokenWriter, 60000*jsonobject.original.length/750 + 3000, jsonobject.original, 60);
        }
        else {
          setTimeout(showResponse, 60000*jsonobject.original.length/750 + 3000, jsonobject.original);
        }
      }
      else {
        //document.getElementById("prompt").innerHTML="[hidden message]";
        //document.getElementById("prompt").style = "color:#638aff";
        document.getElementById("promptarea").style = "display:none";
        if(typewriter[current_phrase]==1){
          setTimeout(tokenWriter, 1000, jsonobject.response, 60);
        }
        else {
          setTimeout(showResponse, 1000, jsonobject.response);
        }
      }
      document.getElementById("prompt").style.animation=null;
      void document.getElementById("prompt").offsetWidth;
      document.getElementById("prompt").style.animation="pop 0.3s linear 2";
      //setTimeout(typeWriter, 3000, jsonobject.original, 40);
      document.getElementById("submit").disabled=true;
      document.getElementById("next").disabled=true;
      document.getElementById("status").innerHTML=(current_phrase+1)+"/"+phrases.length;
  }

  function next_phrase(){
      current_phrase++;
      populate_dialog(phrases[current_phrase]);

  }

  function shuffle(array) {
    let currentIndex = array.length;

    // While there remain elements to shuffle...
    while (currentIndex != 0) {

      // Pick a remaining element...
      let randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;

      // And swap it with the current element.
      [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
    }
  }

  function init(){

    if(!isMobile()){
      //window.location='error.php';
    }
    /*
    Experiments:

    1 - val+ ar+
    2 - val+ ar-
    3 - val- ar+
    4 - val- ar-
    5 - val0 ar0

    */

    // array of typewriter effect conditions
    /*for (i=0;i<20;i++){
      if (i%2 == 1){
        typewriter.push(0);
      }
      else {
        typewriter.push(1);
      }
    }*/

    //shuffle the array
    //shuffle(typewriter);

    //all with typewriter effect
    for (i=0;i<n_questions;i++)
      typewriter.push(1);

    //document.getElementById("namerow").innerHTML=names[random_picks(names,1)[0]]+" "+surnames[random_picks(surnames,1)[0]];
    document.getElementById("next").disabled=true;
    let url = new URL(window.location);
    let params = new URLSearchParams(url.search);
    extype = params.get('type');
    console.log("ex type = "+extype);

    //get data based on experiment type
    switch(parseInt(extype)){
      case 1:
        getData('./phrase_sets/vp_ap.json',n_questions);
        break;
      case 2:
        getData('./phrase_sets/vp_an.json',n_questions);
        break;
      case 3:
        getData('./phrase_sets/vn_ap.json',n_questions);
        break;
      case 4:
        getData('./phrase_sets/vn_an.json',n_questions);
        break;
      case 5:
        n_questions = 5;
        getData('./phrase_sets/v0_a0.json',n_questions);
        break;
    }

    if (extype<1){
      prompts = true;
    }
  }

  function showResponse(text){
    document.getElementById("response").innerHTML = text;
    document.getElementById('inputphrase').disabled=false;
    document.getElementById('inputphrase').focus();
    document.getElementById('inputphrase').click();
  }

  function typeWriter(text, speed) {
    i = document.getElementById("response").innerHTML.length;
    if (i < text.length) {
      document.getElementById("response").innerHTML += text.charAt(i);
      setTimeout(typeWriter, speed, text, speed);
    }
    else {
      document.getElementById('inputphrase').disabled=false;
    }
  }

  function tokenWriter(text, speed) {
    tokens = text.split(" ");
    if (tokens.length >= 2) {
      towrite = tokens[0];
      document.getElementById("response").innerHTML += towrite+" ";
      tokens.shift();
      setTimeout(tokenWriter, speed*towrite.length, tokens.join(" "), speed);
    }
    else {
      document.getElementById("response").innerHTML += tokens[0];
      document.getElementById('inputphrase').disabled=false;
    }
  }

  function mask_phrase(){
    textfield = document.getElementById("inputphrase");
    if (textfield.value.length==0) {
    //  document.getElementById("response").innerHTML="...";
    }
  }


  function rec_key(evt){
    evdata = "";
    if (evt.data!=null  ){
      if (evt.data.length>1){
        evdata="AC";
      }
      else{
        evdata="KP";
      }
    }
    else{
      evdata="KP";
    }

    event = {"participant":localStorage.pid,
              "phrase":phrases[current_phrase].response,
              "event":evdata,
              "data":evt.data,
              "itype":evt.inputType,
              "ts":Date.now(),
              "extype": extype,
              "effect":typewriter[current_phrase]}
    console.log(event);
    if (firstevent==null){
      firstevent=event;
      document.getElementById("submit").disabled=false;
    }
    event_list.push(event);
  }

  function clean(str) {
    str =  str.trim();
    str = str.toLowerCase();
    return str.replace(/[!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~]/g, '');
  }

  function sendtoserver(){

    //calculate lev levenshteinDistance
    var levdist = 0;
    for(i=0;i<sub_phrases.length;i++)
    {
      levdist+=levenshteinDistance(clean(sub_phrases[i].stimulus), clean(sub_phrases[i].submitted));
    }
    levdist=(levdist/sub_phrases.length).toFixed(2);
    wpm=(wpm/sub_phrases.length).toFixed(2);

    data={"events":event_list,
          "phrases":sub_phrases};
    console.log("sending "+ JSON.stringify(data));
    var xhr = new XMLHttpRequest();
    //open the request
    xhr.open('POST','sendtoserver.php');
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("x=" + JSON.stringify(data));

    xhr.onreadystatechange = function() {
        if (xhr.readyState == XMLHttpRequest.DONE) {

            //document.getElementById("results").innerHTML = JSON.parse(this.responseText)['message'];
            result=JSON.parse(this.responseText);
            console.log(result);
            if (result['code']==1){
              exs = JSON.parse(localStorage.experimentorder);
              exs.exorder.shift();
              localStorage.experimentorder=JSON.stringify(exs);
              if (localStorage.wpms){
                localStorage.wpms+=";"+wpm.toString();
              }
              else {
                localStorage.wpms=wpm.toString();
              }
              if (localStorage.edists){
                localStorage.edists += ";"+levdist;
              }
              else{
                localStorage.edists = levdist;
              }
              window.location="questionnaire_AS.php?type="+extype;
            }
            else{
              alert("failed to upload data \n"+JSON.stringify(result));
              window.location='index.php';
            }

        }
    }
    //Dont submit the form.
    return false;
  }

  function enter_response(){
    textfield = document.getElementById("inputphrase");
    textfield.disabled=true;
    lastevent=event_list[event_list.length-1];

    var data = {"stimulus":phrases[current_phrase].response,
                "submitted":textfield.value,
                "participant":localStorage.pid,
                "extype":extype,
                "effect":typewriter[current_phrase],
                "start":firstevent.ts,
                "end":lastevent.ts}
    sub_phrases.push(data);

    wpm +=(clean(data.submitted).length / 5) / ((lastevent.ts - firstevent.ts)/60000);
    firstevent=null;

    document.getElementById("response").innerHTML= phrases[current_phrase].response;//textfield.value;
    //textfield.value="";
    textfield.disabled=true;
    if (current_phrase<phrases.length-1){
      document.getElementById("next").disabled=false;
      document.getElementById("submit").disabled=true;
      document.getElementById("next").focus();
      next_phrase();
    }
    else {
      document.getElementById("next").disabled=true;
      document.getElementById("submit").disabled=true;
      document.getElementById("finished").disabled=false;
      document.getElementById("statusblock").innerHTML="Finished!";
      document.getElementById("finishblock").style="display:block;"
      document.getElementById("instructblock").style="display:none;"
      document.getElementById("nextblock").style="display:none;"
    }
  }
</script>

<style>
.promptbubble{
  background-color: #3366ff;
  color: white;
  border-radius: 12px;
  margin: 0.5em;
  padding: 1em;
}

.responsebubble{
  background-color: #d0756f;
  color: white;
  border-radius: 12px;
  margin: 0.5em;
  padding: 1em;
  font-style: italic;
  -webkit-user-select: none;
  -webkit-touch-callout: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

.responsebubble-small{
  background-color: #d0756f;
  color: white;
  border-radius: 6px;
  padding: 0.1em;
  font-style: italic;
}

i{
  font-size:38px;
  color:#3366ff;
}

h2{
  text-align: center;
}

.backcolor{
  background-color: #d2d2d2;
}

/*#prompt{
  animation: pop 0.3s linear 2;
}*/

@keyframes pop{
  50%  {transform: scale(1.2);}
}

</style>
<!-- Include all compiled plugins (below), or include individual files as needed -->
  </head>
  <body onload="init()">
    <div class="container">
      <div class="row"><h2 id = "namerow"></h2></div>
      <hr>
      <div class="row" id = "promptarea" hidden>
        <div class="col-xs-1"><i class="bi bi-person-circle"></i></div>
        <div class="col-xs-7"><div class ="promptbubble" id = "prompt"></div></div>
        <div class="col-xs-4"></div>
      </div>
      <div class="row">
        <div class="col-xs-4"></div>
        <div class="col-xs-8"><div class="responsebubble" id = "response"></div></div>
      </div>

        <div class="form-row">
          <div class="col-xs-10">
            <input type="text" class="form-control" id="inputphrase" placeholder="Copy the purple bubble phrase!" onkeydown="mask_phrase()" oninput="rec_key(event)" disabled
            autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" style="height:3em;">
          </div>
          <div class="col-xs-2">
            <button type="button" class="btn btn-default" id ="submit" onclick = "enter_response()" disabled style="height:3em;">
              <i class="bi bi-play-circle-fill" style="font-size:1.5em;"></i>
            </button>
          </div>
        </div>

      <div class="row">
        <div class="col-xs-12">
          <hr>
          <h3 id="statusblock" style="text-align:center;">Phrase <span id="status"></span></h3>
          <span id = "instructblock">Please <strong>copy the phrase</strong> exactly as it appears in the <span class="responsebubble-small">coloured</span> bubble, as <strong>quickly</strong> and as <strong>accurately</strong> as you can!</span>
          <hr>
        </div>
        <div class="row" id = "nextblock" style="visibility:hidden">
          <div class="col-xs-12" style="text-align:center"><button type="button" class="btn btn-default" id="next" onclick = "next_phrase()">Next conversation</button></div>
        </div>
    <div class="row" id = "finishblock" style="display:none;">
      <div class="col-xs-12" style="text-align:center"><button type="button" class="btn btn-default" id ="finished" onclick = "sendtoserver()" disabled>Proceed to questionnaire</button></div>
      <!--<div class="col-xs-12" style="text-align:center"><button type="button" class="btn btn-default" id ="restart" onclick = "init()" disabled>Restart</button></div>-->
    </div>
  </div>




  </body>
</html>
