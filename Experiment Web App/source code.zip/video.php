<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1 maximum-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>LLM Corpus Experiment</title>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/platform/1.3.6/platform.min.js"></script>

    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
    <![endif]-->

<script>

function isMobile() {
  const minWidth = 768; // Minimum width for desktop devices
  const regex = /Mobi|Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
  console.log(regex.test(navigator.userAgent));
  console.log(window.innerWidth < minWidth || screen.width < minWidth);
  console.log('ontouchstart' in window && navigator.maxTouchPoints > 1);
  return regex.test(navigator.userAgent) && (window.innerWidth < minWidth || screen.width < minWidth) && ('ontouchstart' in window && navigator.maxTouchPoints > 1);
}

function init(){

  if(!isMobile()){
    //window.location='error.php';
  }

  let url = new URL(window.location);
  let params = new URLSearchParams(url.search);
  extype = params.get('type');
  console.log("ex type = "+extype);

  player=document.getElementById('video');
  videosrc=document.getElementById('mainsrc');

  switch (parseInt(extype)){
    case 1:
      start = 6;
      videosrc.setAttribute('src',"video/1.v+a+.Blur - Song 2.720p.mp4#t="+parseInt(start)+","+parseInt(start+60));
    break;
    case 2:
      start = 6;
      videosrc.setAttribute('src',"video/2.v+a-.Bright Eyes - First Day of My Life.720p.mp4#t="+parseInt(start)+","+parseInt(start+60));
    break;
    case 3:
      start = 211;
      videosrc.setAttribute('src',"video/3.v-a+.AIR - All I Need.720p.mp4#t="+parseInt(start)+","+parseInt(start+60));
    break;
    case 4:
      start = 122;
      videosrc.setAttribute('src',"video/4.v-a-.Dead to Fall - Bastard Set of Dreams.480p.mp4#t="+parseInt(start)+","+parseInt(start+60));
    break;
    case 5:
      start = 31;
      videosrc.setAttribute('src',"video/5.v0-a0.Madonna - Rain.720p.mp4#t="+parseInt(start)+","+parseInt(start+60));
    break;
    default:
      videosrc.setAttribute('src','kekek');
      break;
    }
    player.load();


  player.addEventListener("pause", (event) => {
    console.log("video stopped");
    document.getElementById("play").disabled=true;
    document.getElementById("go").disabled=false;
    //document.getElementById('a').style="visibility:block";
    document.getElementById('b').style="visibility:block";
    document.getElementById('h').style="visibility:block";
    document.getElementById("play").style="visibility:hidden";


  });

}

function play(){
  document.getElementById("play").disabled=true;
  document.getElementById("video").play();
  document.getElementById('a').style="visibility:hidden";
  document.getElementById('b').style="visibility:hidden";
  document.getElementById('h').style="visibility:hidden";


}

function go(){
  let url = new URL(window.location);
  let params = new URLSearchParams(url.search);
  extype = params.get('type');
  window.location = "experiment.php?type="+extype;
}


</script>

<style>

.vertical-center {
  margin: 0;
  position: absolute;
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
.row{
  margin-bottom: 1em;
}
.promptbubble{
  background-color: #3366ff;
  color: white;
  border-radius: 12px;
  margin: 0.5em;
  padding: 1em;
}

.responsebubble{
  background-color: #9966ff;
  color: white;
  border-radius: 12px;
  margin: 0.5em;
  padding: 1em;
  font-style: italic;
}
h1, h3{
  text-align: center;
}

.responsebubble-small{
  background-color: #9966ff;
  color: white;
  border-radius: 6px;
  padding: 0.1em;
  font-style: italic;
}

.promptbubble-small{
  background-color: #3366ff;
  color: white;
  border-radius: 6px;
  padding: 0.1em;
  font-style: italic;
}
input{
  border-radius: 12px;
  width: 100%;
  text-align: center;
}
button:enabled {
  background: #3cb371;
  color: white;
  text-shadow: none;
}

button:disabled {
  background: #dddddd;
}

select{
  border-radius: 12px;
  width: 100%;
  text-align: center;
}

body{
  margin:1em;
  background-color: #000000;
  color: #AAAAAA;
}

/*#prompt{
  animation: pop 0.3s linear 2;
}*/

@keyframes pop{
  50%  {transform: scale(1.2);}
}

</style>
<!-- Include all compiled plugins (below), or include individual files as needed -->
</head>
<body id='body' onload="init()">
  <div id='h'>
  <h1>LLM Corpus Text Entry Experiment</h1>
  <hr/>
</div>
  <!--<h3 id='title'><i class="bi bi-info-square-fill"></i> Task Instructions <i class="bi bi-info-square-fill"></i></h3>
  <hr>-->
  <div class="container">
    <div class="row" id = 'a'>
      <div class = "col-xs-12"> <p style="text-align: center;">Before continuing with the experiment, we ask you to watch this 1-minute video clip. Click "Play" when you're ready to watch it.</div>
    </div>
    <div class="row">
      <div class = "col-xs-12">
        <video id="video"
                controlsList="nodownload nofullscreen noremoteplayback"
                preload="auto"
                width="100%">
                 <source id='mainsrc' src="#" type='video/mp4' />
          </video>
        </div>
      </div>
      <div class="row" id = 'b'>
        <div class="col-xs-6" style="text-align:center;"><button class="btn btn-default" id = "play" onclick="play()">Play</button></div>
        <div class="col-xs-6" style="text-align:center;"><button class="btn btn-default" id = "go" onclick="go()" disabled>Start Experiment</button></div>
      </div>
    </div>
</body>
</html>
