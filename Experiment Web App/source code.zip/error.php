<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>LLM Corpus Experiment</title>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/platform/1.3.6/platform.min.js"></script>

    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
    <![endif]-->

<script>



</script>

<style>
.row{
  margin-bottom: 1em;
}
.promptbubble{
  background-color: #3366ff;
  color: white;
  border-radius: 12px;
  margin: 0.5em;
  padding: 1em;
}

.responsebubble{
  background-color: #9966ff;
  color: white;
  border-radius: 12px;
  margin: 0.5em;
  padding: 1em;
  font-style: italic;
}
h1,h3{
  text-align: center;
}

input{
  border-radius: 12px;
  width: 100%;
  text-align: center;
}

select{
  border-radius: 12px;
  width: 100%;
  text-align: center;
}

body{
  margin:1em;
}

/*#prompt{
  animation: pop 0.3s linear 2;
}*/

@keyframes pop{
  50%  {transform: scale(1.2);}
}

</style>
<!-- Include all compiled plugins (below), or include individual files as needed -->
  </head>
  <body>
    <h1>LLM Corpus Text Entry Experiment</h1>
    <hr/>
  <div class="row">
    <h3><i class="bi bi-exclamation-triangle-fill"></i> Error <i class="bi bi-exclamation-triangle-fill"></i></h3>
    <h3>Please use an Android or iOS smartphone to participate in the study.</h3>
  </div>
</body>
</html>
