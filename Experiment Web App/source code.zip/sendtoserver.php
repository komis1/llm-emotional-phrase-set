<?php
header("Content-Type: application/json; charset=UTF-8");

include "connection.php";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn, "utf8mb4");


$status=[];


// Check connection
if ($conn->connect_error) {
  $status["code"]=0;
  $status["message"]=$conn->connect_error;
}


if (isset($_POST['x'])){
  try{
    $obj = json_decode($_POST["x"], false);

    //save data to file
    $path = 'raw_data/events_'.uniqid().'.json';

    $jsonString = json_encode($obj, JSON_PRETTY_PRINT);
    // Write in the file
    $fp = fopen($path, 'w');
    fwrite($fp, $jsonString);
    fclose($fp);

    $valarray=array();
    foreach($obj->events as $ob) {
      $vals = sprintf("('%s', '%s', '%s', '%s', '%s', from_unixtime(%f), %d, %d)",
          $conn->real_escape_string($ob->participant),
          $conn->real_escape_string($ob->phrase),
          $conn->real_escape_string($ob->event),
          $conn->real_escape_string($ob->data),
          $conn->real_escape_string($ob->itype),
          ($ob->ts/1000),
          $ob->extype,
          $ob->effect);
      //$vals = "('".$ob->participant."','".$ob->phrase."', '".$ob->event."', '".$ob->data."', '".$ob->itype."', from_unixtime(".($ob->ts/1000)."), ".$ob->extype.")";
      $valarray[]= $vals;
    }
    $sql1 = "insert into events (pid, phrase, event, data, itype, ts, extype, effect) values ".implode(",", $valarray);

    // do the phrases
    $valarray=array();
    foreach($obj->phrases as $ob) {
      $vals = sprintf("('%s','%s','%s',%d, %d, from_unixtime(%f), from_unixtime(%f))",
        $conn->real_escape_string($ob->stimulus),
        $conn->real_escape_string($ob->submitted),
        $conn->real_escape_string($ob->participant),
        $ob->extype,
        $ob->effect,
        $ob->start/1000,
        $ob->end/1000);
      //$vals = "('".$ob->stimulus."','".$ob->submitted."','".$ob->participant."',".$ob->extype.")";
      $valarray[]= $vals;
    }
    $sql2 = "insert into phrases (orig_phrase, sub_phrase, pid, extype, effect, start, end) values ".implode(",", $valarray);
    if ($conn->query($sql1) === TRUE && $conn->query($sql2) === TRUE) {
      $status["code"]=1;
      $status["message"]="events added successfully";
      //$status["sql"]=$sql1."; ".$sql2;
    }
    else {
      $status["code"]=0;
      $status["message"]=$conn->error;
    }
  }
  catch(Exception $e){
    $status["code"]=-1;
    $status["message"]=$e->getMessage();
    //$status["sql"]=$sql1."; ".$sql2;
  }

  //$status["code"]=1;
  //$status["received"]=$sql;
}
else{
  if (isset($_POST['p'])){
    $ob = json_decode($_POST["p"], false);

    $vals = sprintf("('%s', '%s', '%s', '%s', %d, %d, %d, '%s', '%s', '%s', '%s', '%s')",
        $conn->real_escape_string($ob->pid),
        $conn->real_escape_string($ob->gender),
        $conn->real_escape_string($ob->english),
        $conn->real_escape_string($ob->fingers),
        $conn->real_escape_string($ob->age),
        $conn->real_escape_string($ob->autocorrect),
        $conn->real_escape_string($ob->wordsuggestions),
        $conn->real_escape_string($ob->timezone),
        $conn->real_escape_string($ob->locale),
        $conn->real_escape_string($ob->ptype),
        $conn->real_escape_string($ob->education),
        $conn->real_escape_string($ob->occupation)


      );


    $sql = "replace into participants (pid, gender, english, fingers, age, autocorrect, wordsuggestions, timezone, locale, ptype, education, occupation) values ".$vals;

    if ($conn->query($sql) === TRUE) {
      $status["code"]=1;
      $status["message"]="events added successfully";
    }
    else {
      $status["code"]=0;
      $status["message"]=$conn->error;
    }

    //$status["code"]=1;
    //$status["received"]=$sql;
  }
  else
  {
    if (isset($_POST['q']))
    {

      try{
        //make the sqlstring field names
        $obj = json_decode($_POST["q"], true);

        //save data to file
        $path = 'raw_data/questionnaires_'.uniqid().'.json';

        $jsonString = json_encode($obj, JSON_PRETTY_PRINT);
        // Write in the file
        $fp = fopen($path, 'w');
        fwrite($fp, $jsonString);
        fclose($fp);


        $sqlstring = "insert into questionnaires (pid, start_time, extype,";
        $quarr=array();
        $valarr=array();

        for ($i=1;$i<=count($obj)-3;$i++){
          $quarr[]=sprintf("q%s", $i);
        }
        $sqlstring.=implode(",",$quarr);

        //make the sprintf placeholders
        $sqlstring.=") values ('%s', from_unixtime(%f), ";

        $quarr=array();
        for ($i=1;$i<=count($obj)-2;$i++){
          $quarr[]="%d";
        }
        $sqlstring.=implode(",", $quarr);
        $sqlstring.=")";



        //make the values array
        $valarr[]= $obj['pid'];
        $valarr[]= $obj['start']/1000;
        $valarr[]= $obj['extype'];

        for ($i=1;$i<=count($obj)-2;$i++){
          $valarr[]=$obj[sprintf("q%s", $i)];
        }

        $sql = vsprintf($sqlstring, $valarr);
        //echo $sql;

        $status["code"]=-2;
        $status["message"]=$sql;

        if ($conn->query($sql) === TRUE) {
          $status["code"]=1;
          $status["message"]="events added successfully";
        }
        else {
          $status["code"]=0;
          $status["message"]=$conn->error;
        }
      }
      catch(Exception $e)
      {
        $status["code"]=-1;
        $status["message"]=$e;
      }
    }
    else
    {
      $status["code"]=0;
      $status["message"]="No data submitted";
    }
  }
}


echo json_encode($status);
?>
